var body = document.querySelector("#siteWrapper header");

function scrolled(){
	var windowHeight = document.body.clientHeight,
		currentScroll = document.body.scrollTop || document.documentElement.scrollTop;
	
	body.className = (currentScroll  - body.offsetHeight) ? "fixed" : "";
}

addEventListener("scroll", scrolled, false);