/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tamagotchi3;

import java.io.File;
import java.util.Scanner;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JOptionPane;
import static tamagotchi3.CreationInterface.Tama;

/**
 *
 * @author lucas
 */
public class Tamagotchi3 {

    private String nom;
    private String couleur;
    private int taille;
    private int poids;
    private int santé;

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCouleur() {
        return couleur;
    }

    public void setCouleur(String couleur) {
        this.couleur = couleur;
    }

    public int getTaille() {
        return taille;
    }

    public void setTaille(int taille) {
        this.taille = taille;
    }

    public int getPoids() {
        return poids;
    }

    public void setPoids(int poids) {
        this.poids = poids;
    }

    public int getSanté() {
        return santé;
    }

    public void setSanté(int santé) {
        this.santé = santé;
    }

    public void playSound(String name) {
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(name).getAbsoluteFile());
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        } catch (Exception ex) {
            System.out.println("Error with playing sound.");
            ex.printStackTrace();
        }
    }
       
    public void bandeSon(){
  
            this.playSound("/home/lucas/Téléchargements/Mario1.wav");
}

    public void creation1() {
                                       this.bandeSon();

        String reponse = JOptionPane.showInputDialog("Bonjour, comment veux tu appeler ton tamagotchi ? ");
               this.playSound("/home/lucas/Téléchargements/TextTo.wav");

        nom = reponse.toUpperCase();

        //Tamagotchi tama1 = new Tamagotchi();
        this.setNom(nom);


        reponse = JOptionPane.showInputDialog("Tu as choisis le nom  " + this.getNom() + "/n" + "  Tu aimerais qu'il soit de quel couleur ? ");
        couleur = reponse;
        this.setCouleur(couleur);

        JOptionPane.showMessageDialog(null, "Tu as choisis la couleur " + this.getCouleur());
        this.playSound("/home/lucas/Téléchargements/13670.wav");

        JOptionPane.showMessageDialog(null, "Maintenant allons le faire éclore ! ");

        /// Le tamagotchi éclos avec swing 
        int poids = (int) (Math.random() * 4 + 2);
        int taille = (int) (Math.random() * 50 + 10); // math.random nombre entre 0 ,et 1 

        this.setPoids(poids);
        this.setTaille(taille);

        JOptionPane.showMessageDialog(null, "L'oeuf a eclos !!!! Il fait " + this.getPoids() + "kilos  et il mesure " + this.getTaille() + "cm");
        JOptionPane.showMessageDialog(null, "Bonjour moi c'est   " + this.getNom() + " tu peux me nourrir, me donner à boire et  parler avec moi");
        JOptionPane.showMessageDialog(null, "Par contre attention à mon poids , je peux mourir si je fais moins de 1 kilos ou + de 50 kilos ");
        JOptionPane.showMessageDialog(null, "Je peux faire 100 cm maximum  nourrissez moi pour que je  grandisse ");
    }

    public void Etat() {

        System.out.println("Mon nom est " + this.nom + "Mon poids est " + this.poids + "Ma taille est " + this.taille + "Ma santé est de " + this.santé);

    }

    public void aide() {

        JOptionPane.showMessageDialog(null, "Si vous vous posez des questions vous etes au bon endroit");
        JOptionPane.showMessageDialog(null, "Bonjour moi c'est   " + this.getNom() + ". Je suis ton Tamagotchi,  tu peux me nourrir, me donner à boire et  parler avec moi");
        JOptionPane.showMessageDialog(null, "Par contre attention à mon poids , je peux mourir si je suis trop gros (+ de 50 kilos) ou trop maigre (- de 1 kilos)");
        JOptionPane.showMessageDialog(null, "Je peux faire 100 cm maximum  nourrissez moi pour que j'atteigne ma taille maximum ");

    }

    public void manger() {
        if (poids > 50) {
            this.mourir();

        } else {
            JOptionPane.showMessageDialog(null, "Trop Bon ! Poids + 2 ! Taille + 3 J'ai bien mangé je fais maintenant  " + this.getPoids() + "kilos et " + this.getTaille() + "cm");
            poids = poids + 2;

            if (taille < 100) {
                taille = taille + 3;
            }
        }

    }

    public void boire() {
        JOptionPane.showMessageDialog(null, "J'avais trop soif ! ");

    }

    public void mourir() {
if(poids>0){
            Tama.playSound("/home/lucas/Téléchargements/TextTo(1).wav");

       JOptionPane.showMessageDialog(null,"Tu m'as tué enfoiré ! ");
        
}

    }

    public void maigrir() {

        poids--;

    }

    public void etat() {

        JOptionPane.showMessageDialog(null, "Moi c'est  " + nom + "  . Je suis de couleur " + couleur + " Je fais " + poids + "kilos et " + taille + "cm");

    }

    public void parler() {

        if (poids > 45 || poids < 2) {

            if (poids < 2) {
                String phrase6 = "Je me suis pesé ce matin je fais 10 kilos je suis une  baguette";
                JOptionPane.showMessageDialog(null, phrase6);

            } else if (poids > 45) {
                String phrase5 = "Je me suis pesé ce matin je fais 35 kilos laisse tomber faut que je maigrisse ";
                JOptionPane.showMessageDialog(null, phrase5);
            }

        } else {
            String phrase1 = "Como estas?";
            String phrase2 = "Tu vas bien ?";

            String phrase3 = "How are you ? ?";

            String phrase4 = "Tu veux faire quoi aujourd'hui ? ";

            String phrase7 = "T'as vu je parle 3 langues ?";

            String phrase8 = "Bon bref ";
            String phrase9 = "Je suis fatigué ";
            String phrase10 = "Qu'est ce que tu veux toi ? ";

            //       JOptionPane.showMessageDialog(null, phrase);
            int nbAleatoire = (int) (Math.random() * 8);
            String[] tab = {phrase1, phrase2, phrase3, phrase4, phrase7, phrase8, phrase9, phrase10};
            JOptionPane.showMessageDialog(null, tab[nbAleatoire]);

        }

    }

    public void courir() {

        if (poids < 5) {

            JOptionPane.showMessageDialog(null, "J'ai trop faim pour courir ? tu veux que je me foule la cheville ?? ");

        } else {
            String reponse = JOptionPane.showInputDialog(null, "T'es sur qu'on fait du sport j'ai la flemme ? ");

            if (reponse.equals("oui")) {

                JOptionPane.showMessageDialog(null, "Bon ok je me met en survet ! ");

                poids = poids - 4;
                JOptionPane.showMessageDialog(null, "J'ai beaucoup couru ! j'ai fait 3 km en 50 minutes!  j'ai perdu  4 kilos");
                JOptionPane.showMessageDialog(null, "Maintenant je fais " + poids + "kilos");

            }
        }

    }

    /**
     * * FIN METHODES TAMAGOTCHI ***
     */
}
