package tamagotchi;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class Jeu {

	
	Tamagotchi tama1 = new Tamagotchi (); 
	
	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] nom) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Jeu Jeu = new Jeu();
					Jeu.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Jeu() {
		this.tama1 = Creation.tama1;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton btnOl = new JButton("Manger");
		btnOl.setBounds(22, 24, 218, 17);
		btnOl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				tama1.manger();

			}
		});
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(btnOl);
		
		JButton btnBoire = new JButton("Boire");
		btnBoire.setBounds(211, 9, 160, 16);
		btnBoire.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				tama1.boire();
				
			}
		});	
		frame.getContentPane().add(btnBoire);
		
		JButton btnParler = new JButton("parler");
		btnParler.setBounds(12, 75, 187, 25);
		btnParler.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tama1.parler();
			}
		});
		frame.getContentPane().add(btnParler);
		
		JButton btnAide = new JButton("Aide");
		btnAide.setBounds(317, 37, 64, 49);
		btnAide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tama1.aide();
			}
		});
		frame.getContentPane().add(btnAide);
		
		JButton btnAllerCourir = new JButton("Aller Courir");
		btnAllerCourir.setBounds(32, 49, 141, 25);
		btnAllerCourir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tama1.courir();
			}
		});
		frame.getContentPane().add(btnAllerCourir);
	}
}

