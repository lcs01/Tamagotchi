package tamagotchi;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class Tamagotchi { /// pour utiliser le tamagotchi dans sa propre classe on utilise this. (this = lui meme)






	/*** ATTRIBUTS TAMAGOTCHI ****/
	private String nom;
	private String couleur ; 
	private int taille ; 
	private int poids ;
	private int santé ;
	private String etat; 


	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getCouleur() {
		return couleur;
	}
	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}
	public int getTaille() {
		return taille;
	}
	public void setTaille(int taille) {
		this.taille = taille;
	}
	public int getPoids() {
		return poids;
	}
	public void setPoids(int poids) {
		this.poids = poids;
	} 

	public int getSanté() {
		return santé;
	}
	public void setSanté(int santé) {
		this.santé = santé;
	}

	public String getEtat() {
		return etat;
	}
	public void setEtat(String etat) {
		this.etat = etat;
	}


	/*** FIN  ATTRIBUTS TAMAGOTCHI ****/

	/*** METHODES TAMAGOTCHI ****/


	public void creation() {
		String reponse = JOptionPane.showInputDialog("Bonjour, comment veux tu appeler ton tamagotchi ? ");
		nom = reponse.toUpperCase();; 

		//Tamagotchi tama1 = new Tamagotchi();

		this.setNom(nom);


		reponse = JOptionPane.showInputDialog("Tu as choisis le nom  " +this.getNom() + "/n" +  "  Tu aimerais qu'il soit de quel couleur ? "); 
		couleur = reponse; 
		this.setCouleur(couleur);

		JOptionPane.showMessageDialog(null, "Tu as choisis la couleur " + this.getCouleur());


		JOptionPane.showMessageDialog(null, "Maintenant allons le faire éclore ! ");		

		/// Le tamagotchi éclos avec swing 


		int poids= (int)(Math.random()*4+2);
		int taille= (int)(Math.random()*50+10); // math.random nombre entre 0 ,et 1 

		this.setPoids(poids);
		this.setTaille(taille);
		
		JOptionPane.showMessageDialog(null , "L'oeuf a eclos !!!! Il fait " + this.getPoids() + "kilos  et il mesure " + this.getTaille()+ "cm");
		JOptionPane.showMessageDialog(null, "Bonjour moi c'est   " + this.getNom() + " tu peux me nourrir, me donner à boire et  parler avec moi");
		JOptionPane.showMessageDialog(null, "Par contre attention à mon poids , je peux mourir si je fais moins de 1 kilos ou + de 50 kilos ");
		JOptionPane.showMessageDialog(null, "Je peux faire 100 cm maximum  nourrissez moi pour que je  grandisse ");

	

	}
	
	public void aide () {
		
		JOptionPane.showMessageDialog(null , "Si vous vous posez des questions vous etes au bon endroit");
		JOptionPane.showMessageDialog(null, "Bonjour moi c'est   " + this.getNom() + ". Je suis ton Tamagotchi,  tu peux me nourrir, me donner à boire et  parler avec moi");
		JOptionPane.showMessageDialog(null, "Par contre attention à mon poids , je peux mourir si je suis trop gros (+ de 50 kilos) ou trop maigre (- de 1 kilos)");
		JOptionPane.showMessageDialog(null, "Je peux faire 100 cm maximum  nourrissez moi pour que j'atteigne ma taille maximum ");
		
		
	}

	public void manger () {
		if(poids > 50) {
			this.mourir();
			
			
		}
		else {
		JOptionPane.showMessageDialog(null, "Trop Bon ! Poids + 2 ! Taille + 3 J'ai bien mangé je fais maintenant  " +  this.getPoids() +  "kilos et " + this.getTaille() + "cm");
		poids = poids + 2;

		if(taille <100) {
			taille = taille + 3 ; 
		}
		}
	
	}

	public void boire () {
		JOptionPane.showMessageDialog(null, "J'avais trop soif ! ");

	}
	public void mourir() {



		System.out.println("Tu m'as tué enfoiré ! ");



	}
	
	public void maigrir () {
		
		poids -- ; 

	}

	public void parler () {



		JOptionPane.showMessageDialog(null, "Moi c'est  " + nom  + "  . Je suis de couleur " + couleur + " Je fais " + poids + "kilos et " + taille + "cm");

		System.out.println("Moi c'est  " + nom + "  . JE SUIS DE COULEUR " + couleur + " JE FAIS " + poids + "kilos ET  " + taille + "cm");
	}
  
	
public void courir (){
	
	
	  if(poids < 5) {
		   
			JOptionPane.showMessageDialog(null, "J'ai trop faim pour courir ? tu veux que je me foule la cheville ?? " );

			
	  }
	  
	  
	  else {
			String reponse = JOptionPane.showInputDialog(null, "T'es sur qu'on fait du sport j'ai la flemme ? ");
   
	   

			if(reponse.equals("oui")) {
		
		 
		JOptionPane.showMessageDialog(null, "Bon ok je me met en survet ! " );
		
		poids = poids -4;
		JOptionPane.showMessageDialog(null, "J'ai beaucoup couru ! j'ai fait 3 km en 50 minutes!  j'ai perdu  4 kilos" );
		JOptionPane.showMessageDialog(null, "Maintenant je fais " + poids + "kilos" );

 
	}
	  }
	  

}


	/*** FIN METHODES TAMAGOTCHI ****/








}
