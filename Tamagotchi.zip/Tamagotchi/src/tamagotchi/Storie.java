/*package tamagotchi;

import java.util.Scanner;

import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;

public class Storie {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		//Création de votre Tamagotchi :
		/* Choix nom
		 * Choix couleur
		 * poids à la naissance
		 * taille  à la naissance 
		 */

/*


		System.out.println(" Hello comment veux tu appeler ton tamagotchi ? ");
		Scanner scanner = new Scanner(System.in);
		String saisie = scanner.nextLine().toUpperCase();		

		Tamagotchi tama1 = new Tamagotchi();

/*
		tama1.setNom(saisie);


		System.out.println("Tu as choisis le nom  " +tama1.getNom()); 

		System.out.println("Tu aimerais qu'il soit de quel couleur ? ");

		saisie= scanner.nextLine(); 

		tama1.setCouleur(saisie);
		System.out.println("Tu vas choisis la couleur " + tama1.getCouleur());


		System.out.println("Maintenant allons le faire éclore ! ");		

		/// Le tamagotchi éclos avec swing 


		int poids= (int)(Math.random()*3+1);
		int taille= (int)(Math.random()*50+10); // math.random nombre entre 0 ,et 1 

		tama1.setPoids(poids);
		tama1.setTaille(taille);


		System.out.println("IL A ECLOS !!! Il fait " + tama1.getPoids() + "kilos  et il mesure " + tama1.getTaille()+ "cm");
*/

     // le tamagotchi a maintenant tous ses attributs 
		
		
		
		// le tamagotchi viens nous parler en swing 
		//System.out.println("Bonjour moi c'est   " + tama1.getNom() + " tu peux me nourrir, me donner à boire et  parler avec moi");
	//	System.out.println("Par contre attention à mon poids , je peux mourir si je fais moins de 1 kilos ou + de 50 kilos ");
		//System.out.println("Je peux faire 100 cm maximum  nourrissez moi pour que je  grandisse ");
	//	System.out.println("Pour connaitre mon état de santé et mes informations cliquez sur le bouton 1 ");
		//JOptionPane.showMessageDialog(null, "Tama" + tama1.getNom());
	//	String reponse = JOptionPane.showInputDialog("Tu veux me nourrir ? ");
                /*
			tama1.manger();

		
	
		
	
		System.out.println(tama1.getNom() + " fait " + tama1.getPoids() + " kilos ");
		System.out.println(tama1.getNom()+ "  fait " + tama1.getTaille() + "cm");
		
		
		tama1.parler();
		
		
		if(tama1.getPoids()< 1 || tama1.getPoids() > 50 ) {
			
			tama1.mourir();
		}
		
	
		UIManager.setLookAndFeel(new NimbusLookAndFeel() );
		Swing Swing= new Swing();
		
		Swing.setVisible(true);
		



		scanner.close();

	}}






*/